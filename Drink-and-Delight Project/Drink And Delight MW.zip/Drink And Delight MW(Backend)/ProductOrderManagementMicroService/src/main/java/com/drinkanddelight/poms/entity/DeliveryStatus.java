package com.drinkanddelight.poms.entity;

public enum DeliveryStatus {

	BOOKED,DELIVERED,DISPATCHED,CANCELLED;
}
