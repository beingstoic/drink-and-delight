package com.drinkanddelight.poms.exception;

public class WarehouseException extends Exception{
	
	private static final long serialVersionUID = 1L;
	public WarehouseException(String msg)
	{
		super(msg);
	}


}
