package com.drinkanddelight.poms.exception;

public class DistributorException extends Exception {

	private static final long serialVersionUID = 1L;
	public DistributorException(String msg)
	{
		super(msg);
	}

}
