package com.sunhome.poms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductOrderManagementMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
