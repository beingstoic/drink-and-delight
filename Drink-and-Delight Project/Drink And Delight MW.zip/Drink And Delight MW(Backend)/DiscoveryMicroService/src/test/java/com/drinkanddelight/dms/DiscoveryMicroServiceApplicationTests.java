package com.drinkanddelight.dms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
