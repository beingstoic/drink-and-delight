package com.drinkanddelight.gms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
