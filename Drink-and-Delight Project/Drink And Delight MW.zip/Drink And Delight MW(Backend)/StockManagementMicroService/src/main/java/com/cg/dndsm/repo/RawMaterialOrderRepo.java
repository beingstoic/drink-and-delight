package com.cg.dndsm.repo;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.cg.dndsm.entity.RawMaterialOrderEntity;
/*
public interface RawMaterialOrderRepo extends JpaRepository<RawMaterialOrderEntity, Long>{

}
*/