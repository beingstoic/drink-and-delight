package com.cg.dndsm.service;

import com.cg.dndsm.model.RawMaterialOrderModel;

public interface RawMaterialOrderService {
	
	public RawMaterialOrderModel findById(long orderId);

}
