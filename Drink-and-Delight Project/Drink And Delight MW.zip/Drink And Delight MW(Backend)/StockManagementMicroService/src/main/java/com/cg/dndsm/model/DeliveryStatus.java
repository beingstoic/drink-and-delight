package com.cg.dndsm.model;

public enum DeliveryStatus {
	BOOKED,DELIVERED,DISPATCHED,CANCELLED;
}
