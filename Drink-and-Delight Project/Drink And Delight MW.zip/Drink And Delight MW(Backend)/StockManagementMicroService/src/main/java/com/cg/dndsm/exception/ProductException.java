package com.cg.dndsm.exception;

public class ProductException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public ProductException(String msg) {
		super(msg);
	}


}
