package com.cg.dndsm.service;

import com.cg.dndsm.model.RawMaterialModel;

public interface TrackRawMaterialService {
	public RawMaterialModel findById(long orderId);
}
