package com.cg.dndsm.repo;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.cg.dndsm.entity.ProductOrderEntity;
/*
public interface ProductOrderRepo extends JpaRepository<ProductOrderEntity, Long>{

}
*/