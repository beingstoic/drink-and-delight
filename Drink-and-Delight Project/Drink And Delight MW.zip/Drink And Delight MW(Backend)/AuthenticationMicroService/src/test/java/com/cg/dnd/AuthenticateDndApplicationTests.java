package com.cg.dnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticateDndApplicationTests {

	@Test
	void contextLoads() {
	}

}
