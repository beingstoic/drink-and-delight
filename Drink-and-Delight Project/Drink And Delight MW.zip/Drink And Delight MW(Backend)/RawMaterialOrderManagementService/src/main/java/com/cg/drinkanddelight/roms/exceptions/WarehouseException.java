package com.cg.drinkanddelight.roms.exceptions;

public class WarehouseException extends Exception{
	
	private static final long serialVersionUID = 1L;
	public WarehouseException(String msg)
	{
		super(msg);
	}


}
