package com.cg.drinkanddelight.roms.entity;

public enum DeliveryStatus {

	BOOKED,DELIVERED,DISPATCHED,CANCELLED;
}
