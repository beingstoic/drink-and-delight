package com.cg.drinkanddelight.roms.exceptions;

	public class RawMaterialException extends Exception {

		private static final long serialVersionUID = 1L;

		public RawMaterialException(String msg){
	        super(msg);
	    }
}

