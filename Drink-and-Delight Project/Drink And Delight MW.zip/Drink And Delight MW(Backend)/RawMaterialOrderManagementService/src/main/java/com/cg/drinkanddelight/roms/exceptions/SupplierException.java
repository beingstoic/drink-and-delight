package com.cg.drinkanddelight.roms.exceptions;

public class SupplierException extends Exception {

	private static final long serialVersionUID = 1L;
	public SupplierException(String msg)
	{
		super(msg);
	}

}
