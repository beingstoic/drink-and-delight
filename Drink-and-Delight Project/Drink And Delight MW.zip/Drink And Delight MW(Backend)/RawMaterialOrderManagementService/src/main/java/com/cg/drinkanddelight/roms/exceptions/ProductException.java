package com.cg.drinkanddelight.roms.exceptions;

public class ProductException extends Exception{
	
	private static final long serialVersionUID = 1L;
	public ProductException(String msg)
	{
		super(msg);
	}

}
