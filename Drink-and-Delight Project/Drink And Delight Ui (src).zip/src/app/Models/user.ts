export class User {
    public username:string;
    public gender:string;
    public emailId:string;
    public password:string;
  token: string;
}
