export class Product{
    productId:string;
    productName:string;
    productCost:string;
    productOnline:string;
    productCategory:string;
    productStore:any={Store:[]};
  
    constructor(){}
}